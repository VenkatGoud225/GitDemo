﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace aspnet4_test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }

        [TestMethod]
        public void TestMethod2()
        {
        }
    }
}
